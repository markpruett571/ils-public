<?php

function check_permissions() {
    // Verify the nonce
    if (!isset($_POST['_wpnonce']) || !wp_verify_nonce($_POST['_wpnonce'], 'internal_link_scope')) {
        wp_die('Invalid request');
    }
    
    // Check user capability
    if (!current_user_can('manage_options')) {
        wp_die('Insufficient permission');
    }
}

function post_data_query($limitToPostId = null, $startFromPostId = null) {
    // Query for all posts
    $args = [
        'post_type' => 'post',
        'post_status' => 'publish',
        'posts_per_page' => -1,
        'orderby' => 'ID',
        'order' => 'ASC'
    ];

    if ($limitToPostId) {
        $args['p'] = $limitToPostId;
    }

    if ($startFromPostId) {
        $args['date_query'] = [
            [
                'column' => 'ID',
                'after' => $startFromPostId,
            ],
        ];
    }
    
    return new WP_Query($args);
}

function export_to_csv($data, $filename, $columns) {
    // Send download headers
    header('Content-Type: text/csv; charset=utf-8');
    header('Content-Disposition: attachment; filename=' . $filename);

    // Create a file pointer connected to the output stream
    $output = fopen('php://output', 'w');

    // Output the column headings
    fputcsv($output, $columns);

    // Output the data
    foreach ($data as $row) {
        fputcsv($output, $row);
    }

    // Close the output stream
    fclose($output);

    // End execution to avoid extra output
    die();
}

function export_headers_to_csv() {
    check_permissions();
    
    $query = post_data_query();
    $headers = [];

    if ($query->have_posts()) {
        while ($query->have_posts()) {
            $query->the_post();

            // Extract headers from the post content
            preg_match_all('/<h([1-6])[^>]*>(.*?)<\/h\1>/is', apply_filters('the_content', get_the_content()), $matches);

            for ($i = 0; $i < count($matches[0]); $i++) {
                $header_tag = 'H' . $matches[1][$i];
                $header_text = strip_tags($matches[0][$i]);

                // Add the header to the array
                $headers[] = [
                    'post_id' => get_the_ID(),
                    'post_title' => get_the_title(),
                    'post_url' => get_the_permalink(),
                    'header_tag' => $header_tag,
                    'header_text' => $header_text,
                ];
            }
        }
        // Reset Post Data
        wp_reset_postdata();
    }

    // Insert the headers into the plugin's headers table
    global $wpdb;
    $table_name = $wpdb->prefix . 'ils_headers';

    foreach ($headers as $header) {
        $wpdb->insert($table_name, $header);
    }
}

function get_last_processed_post_id() {
    $lastPostId = get_option('ils_last_processed_post_id', 0);
    
    return $lastPostId;
}

function update_last_processed_post_id($postId) {
    update_option('ils_last_processed_post_id', $postId);
}

function get_next_unprocessed_post_id($lastPostId) {
    global $wpdb;
    $nextPostId = $wpdb->get_var("SELECT ID FROM {$wpdb->posts} WHERE post_type = 'post' AND post_status = 'publish' AND ID > $lastPostId ORDER BY ID ASC LIMIT 1");
    return $nextPostId ? $nextPostId : null;
}

function get_processed_posts_count() {
    $count = get_option('ils_processed_posts_count', 0);
    return $count;
}

function update_processed_posts_count($count) {
    update_option('ils_processed_posts_count', $count);
}

function reset_internal_link_analysis() {
    // Reset the options
    update_option('ils_last_processed_post_id', 0);
    update_option('ils_processed_posts_count', 0);

    // Truncate the internal links table
    global $wpdb;
    $tableName = $wpdb->prefix . 'ils_internal_links';
    $wpdb->query("TRUNCATE TABLE $tableName");
}

function analyze_internal_links() {
    check_ajax_referer('internal_link_scope', 'security');

    $lastPostId = get_option('ils_last_processed_post_id', 0);
    $nextPostId = get_next_unprocessed_post_id($lastPostId);
    
    if ($nextPostId) {
        update_ils_table($nextPostId);
    }

    $totalPosts = wp_count_posts()->publish;
    $processedPosts = get_option('ils_processed_posts_count', 0);

    echo json_encode([
        'progress' => ($processedPosts / $totalPosts) * 100,
        'remainingPosts' => $totalPosts - $processedPosts,
    ]);

    wp_die(); // this is required to terminate immediately and return a proper response
}

function update_ils_table($limitToPostId, $updatingPost = false) {
    if ($limitToPostId) {
        $query = post_data_query($limitToPostId);
    } else {
        $lastPostId = get_last_processed_post_id();
        $query = post_data_query(null, $lastPostId);
    }
    
    $links = [];
    
    if ($query->have_posts()) {
        while ($query->have_posts()) {
            $query->the_post();
    
            // Extract links from the post content
            preg_match_all('/<a(.*?)href="([^"]+)"(.*?)>(.*?)<\/a>/i', apply_filters('the_content', get_the_content()), $matches);
    
            for ($i = 0; $i < count($matches[2]); $i++) {
                $href = sanitize_text_field($matches[2][$i]);
                $text = sanitize_text_field($matches[4][$i]);
    
                // Check if the link is internal
                if (strpos($href, get_site_url()) === 0) {
                    // Parse URLs to remove potential URL parameters or anchor tags
                    $parsed_current_url = parse_url(get_the_permalink());
                    $parsed_link_url = parse_url($href);
    
                    // Check if the URLs point to the same page
                    if ($parsed_current_url['path'] != $parsed_link_url['path']) {
                        // Get the post ID of the linked post
                        $post_id = url_to_postid($href);
    
                        // Check if the post ID exists and is published
                        $linked_post = get_post($post_id);
                        if ($post_id != 0 && $linked_post != null) {
                            // Add the link to the array
                            $links[] = [
                                'from_post_id' => get_the_ID(),
                                'to_post_id' => $post_id,
                                'link_text' => $text,
                            ];
                        }
                    }
                }
            }
        }
        // Reset Post Data
        wp_reset_postdata();
    }
    
    global $wpdb;
    $tableName = $wpdb->prefix . 'ils_internal_links';

    // Insert the internal links into the plugin's internal links table
    $wpdb->query('START TRANSACTION');

    if ($updatingPost) {
        $wpdb->query($wpdb->prepare("DELETE FROM %i WHERE from_post_id = %d", $tableName, $limitToPostId));
    }

    foreach ($links as $link) {
        $wpdb->insert($tableName, $link);
    }

    if (!$updatingPost) {
        // Update the last processed post ID
        update_last_processed_post_id(get_the_ID());

        update_processed_posts_count(get_processed_posts_count() + 1);
    }

    $wpdb->query('COMMIT');
}
