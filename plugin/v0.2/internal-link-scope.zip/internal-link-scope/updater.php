<?php

// Want to build your own self-hosted updates? Check out this article by Austin Ginder at https://anchor.host/using-github-to-self-host-updates-for-wordpress-plugins/

function internal_link_scope_info($res, $action, $args) {
    
    if ($action !== 'plugin_information') {
        return $res;
    }

    if ($args->slug !== plugin_basename(__DIR__)) {
        return $res;
    }

    $remote = update_request();

    $res = new stdClass();
	$res->name = $remote->name;
	$res->slug = $remote->slug;
	$res->author = $remote->author;
	$res->author_profile = $remote->author_profile;
	$res->version = $remote->version;
	$res->tested = $remote->tested;
	$res->requires = $remote->requires;
	$res->requires_php = $remote->requires_php;
	$res->download_link = $remote->download_url;
	$res->trunk = $remote->download_url;
	$res->last_updated = $remote->last_updated;
	$res->sections = [
		'description' => $remote->sections->description,
		'installation' => $remote->sections->installation,
		'changelog' => $remote->sections->changelog
    ];

    return $res;
}
add_filter('plugins_api', 'internal_link_scope_info', 20, 3);

function update_request() {
    $remote = wp_remote_get('https://raw.githubusercontent.com/markpruett571/ils-public/main/plugin.json', [
        'timeout' => 10,
        'headers' => ['Accept' => 'application/json']
    ]);
    
    if (is_wp_error($remote)) {
        return false;
    }

    $remote_plugin_data = json_decode(wp_remote_retrieve_body($remote));

    if ($remote_plugin_data === null) {
        return false;
    }

    return $remote_plugin_data;
}

function update($transient) {

    if (empty($transient->checked)) {
        return $transient;
    }

    $remote = update_request();

    if ($remote && version_compare(ILS_VERSION, $remote->version, '<') && version_compare($remote->requires, get_bloginfo( 'version' ), '<=') && version_compare($remote->requires_php, PHP_VERSION, '<')) {
        $response              = new \stdClass();
        $response->slug        = 'internal-link-scope';
        $response->plugin      = "internal-link-scope/plugin.php";
        $response->new_version = $remote->version;
        $response->tested      = $remote->tested;
        $response->package     = $remote->download_url;

        $transient->response[ $response->plugin ] = $response;

    }

    return $transient;
}
add_filter('site_transient_update_plugins', 'update');