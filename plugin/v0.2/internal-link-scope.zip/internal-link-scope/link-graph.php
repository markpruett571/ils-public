<?php

function add_link_graph_page() {
    add_submenu_page(
        'internal_link_scope', // parent slug
        'Link Graph', // page title
        'Link Graph', // menu title
        'manage_options', // capability
        'link-graph', // menu slug
        'link_graph_callback' // function
    );
}

function enqueue_cytoscape() {
    if (!isset($_GET['page']) || !$_GET['page'] === 'link-graph') {
        return;
    }

    wp_enqueue_script('cytoscape', plugin_dir_url(__FILE__) . 'js/cytoscape.min.js', array(), '3.26.3');
}
add_action('admin_enqueue_scripts', 'enqueue_cytoscape');

// Only add this if on the Link Graph page
if (isset($_GET['page']) && $_GET['page'] === 'link-graph') {
    add_action('admin_enqueue_scripts', 'enqueue_cytoscape');
}

function link_graph_callback() {
    global $wpdb;

    $query = "
        SELECT wp_posts.post_title, wp_posts.ID
        FROM {$wpdb->prefix}posts AS wp_posts
        WHERE wp_posts.post_status = 'publish' AND wp_posts.post_type = 'post'
    ";

    $results = $wpdb->get_results($query);

    $query_links = "
        SELECT *
        FROM {$wpdb->prefix}ils_internal_links
    ";

    $links_results = $wpdb->get_results($query_links);
    
    ?>

    <div class="wrap">
        <h1>Link Graph</h1>
        <div id="cy" style="width: 100wh;height:80vh;"></div>
        <script>
            let cy = cytoscape({
                container: document.getElementById('cy'), // container to render in
                
                elements: [ // list of graph elements to start with
                <?php foreach ($results as $result) { ?>
                {
                    data: { id: '<?php echo $result->ID; ?>', label: '<?php echo str_replace("'", "\\'", $result->post_title); ?>' },
                },
                <?php } ?>
                <?php foreach ($links_results as $link) { ?>
                {
                    data: { id: '<?php echo $link->from_post_id . '-' . $link->to_post_id; ?>', source: '<?php echo $link->from_post_id; ?>', target: '<?php echo $link->to_post_id; ?>' },
                },
                <?php } ?>
                ],

                style: [ // the stylesheet for the graph
                {
                    selector: 'node',
                    style: {
                        'label': 'data(label)'
                    }
                },

                {
                    selector: 'edge',
                    style: {
                        'width': 3,
                        'line-color': '#ccc',
                        'target-arrow-color': '#ccc',
                        'target-arrow-shape': 'triangle',
                        'curve-style': 'bezier'
                    }
                }
                ],

                layout: {
                    name: 'concentric',
                    // rows: 1
                }
            });

            // Bind the click event to the nodes
            cy.on('tap', 'node', function(evt){
                let node = evt.target;
                let postId = node.data('id');
                window.location.href = '/wp-admin/post.php?post=' + postId + '&action=edit';
            });
            
            let maxDegree = 0;

            cy.nodes().forEach(function( node ){
                let incomingEdges = node.connectedEdges('[target = "' + node.id() + '"]');
                let degree = incomingEdges.length;
                maxDegree = Math.max(maxDegree, degree);
            });

            cy.nodes().forEach(function( node ){
                let incomingEdges = node.connectedEdges('[target = "' + node.id() + '"]');
                let degree = incomingEdges.length;

                if (degree === 0) {
                    return 'rgb(128, 128, 128)'; // return gray if no links
                }

                let green = Math.floor((degree / maxDegree) * 255);
                green = Math.min(255, green); // ensure not greater than 255

                let red = 255 - green;

                node.style('background-color', 'rgb(' + red + ',' + green + ',0)');
            });
        </script>
    </div>

    <?php
}