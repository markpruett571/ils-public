<?php

function create_tables() {
    global $wpdb;
    require_once( ABSPATH . 'wp-admin/includes/upgrade.php' );

    $pluginTablePrefix = 'ils';

    // Headers
    $table_name = $wpdb->prefix . $pluginTablePrefix . '_' . 'headers';

    $sql = "CREATE TABLE $table_name (
        id mediumint(9) NOT NULL AUTO_INCREMENT,
        post_id bigint(20) NOT NULL,
        post_title varchar(255) NOT NULL,
        post_url varchar(255) NOT NULL,
        header_tag varchar(10) NOT NULL,
        header_text varchar(255) NOT NULL,
        PRIMARY KEY  (id)
    ) $charset_collate;";

    dbDelta( $sql );

    // Internal Links
    $table_name = $wpdb->prefix . $pluginTablePrefix . '_' . 'internal_links';

    $sql = "CREATE TABLE $table_name (
        id mediumint(9) NOT NULL AUTO_INCREMENT,
        from_post_id bigint(20) NOT NULL,
        to_post_id bigint(20) NOT NULL,
        link_text varchar(255) NOT NULL,
        PRIMARY KEY  (id)
    ) $charset_collate;";

    dbDelta( $sql );
}