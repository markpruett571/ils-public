<?php
/*
 * Plugin Name:     Internal Link Scope
 * Plugin URL:      https://markpruett.com/internal-link-scope
 * Description:     Analyze the internal link structure of your website.
 * Version:         0.2
 * Author:          Mark Pruett
 * Author URI:      https://markpruett.com
 * License:         GPL v2
 * License URI:     https://www.gnu.org/licenses/gpl-2.0.html
*/

if (!defined('ILS_VERSION')) {
    define('ILS_VERSION', '0.2');
}

require_once plugin_dir_path(__FILE__) . 'install.php';
require_once plugin_dir_path(__FILE__) . 'updater.php';
require_once plugin_dir_path(__FILE__) . 'export-functions.php';
require_once plugin_dir_path(__FILE__) . 'link-graph.php';
require_once(ABSPATH . 'wp-admin/includes/screen.php');
require_once(ABSPATH . 'wp-admin/includes/plugin.php');

register_activation_hook( __FILE__, 'create_tables' );

function uninstall_ils() {
    global $wpdb;
    
    $wpdb->query("DROP TABLE IF EXISTS {$wpdb->prefix}ils_internal_links");
    $wpdb->query("DROP TABLE IF EXISTS {$wpdb->prefix}ils_headers");

    delete_option('ils_last_processed_post_id');
    delete_option('ils_processed_posts_count');    
}

register_uninstall_hook(__FILE__, 'uninstall_ils');

function run_analyze_internal_links($post_id) {
    // Check if the post is being updated
    if (wp_is_post_revision($post_id)) {
        return;
    }

    // Run the analyze_internal_links function
    update_ils_table($post_id, true);
}
add_action('save_post', 'run_analyze_internal_links');

function add_link_counts_column($columns) {
    $columns['internal_links'] = 'Internal Links';
    return $columns;
}
add_filter('manage_posts_columns', 'add_link_counts_column');

function get_link_counts() {
    global $wpdb;
    $table_name = $wpdb->prefix . 'ils_internal_links';

    $query = "SELECT to_post_id, COUNT(*) AS link_count FROM $table_name GROUP BY to_post_id";
    $link_counts = $wpdb->get_results($query, ARRAY_A);

    return $link_counts;
}

function display_link_counts_column($column, $post_id) {
    if ($column === 'internal_links') {
        static $link_counts = null;

        if ($link_counts === null) {
            $link_counts = get_link_counts();
        }

        $count = 0;

        foreach ($link_counts as $link_count) {
            if ($link_count['to_post_id'] == $post_id) {
                $count = $link_count['link_count'];
                break;
            }
        }

        echo $count;
    }
}
add_action('manage_posts_custom_column', 'display_link_counts_column', 10, 2);

function make_column_sortable($columns) {
    $columns['internal_links'] = 'internal_links';

    return $columns;
}
add_filter('manage_edit-post_sortable_columns', 'make_column_sortable');

function modify_orderby_clause($orderby_statement) {
    global $wp_query;

    // Return early if user is not an admin
    if (!current_user_can('manage_options')) {
        return $orderby_statement;
    }

    if ('internal_links' === $wp_query->get('orderby')) {
        $orderby_statement = 'ils.link_count ' . $wp_query->get('order');
    }

    return $orderby_statement;
}
add_filter('posts_orderby', 'modify_orderby_clause');


function ils_join_to_WPQuery($join) {
    global $wpdb;
    $tableName = $wpdb->prefix . 'ils_internal_links';

    // Check if the current screen is the posts list screen
    $current_screen = get_current_screen();
    if ($current_screen && $current_screen->base === 'edit') {
        $join .= "LEFT JOIN (
            SELECT to_post_id, COUNT(*) AS link_count FROM $tableName GROUP BY to_post_id
        ) AS ils
        ON $wpdb->posts.ID = ils.to_post_id";
    }

    return $join;
}

add_filter('posts_join', 'ils_join_to_WPQuery');

// Hook for 'admin_post_' . $action
add_action('admin_post_export_headers', 'export_headers_to_csv');
add_action('admin_post_export_links', 'analyze_internal_links');
add_action('admin_post_export_link_counts', 'export_internal_link_counts_to_csv');

// Add menu page in the Dashboard
function add_main_menu() {
    add_menu_page(
        'Internal Link Scope', // page title
        'Internal Link Scope', // menu title
        'manage_options', // capability
        'internal_link_scope', // menu slug
        'internal_link_scope_callback', // function
        'dashicons-admin-links', // icon url
        70 // position
    );
}
add_action('admin_menu', 'add_main_menu');
add_action('admin_menu', 'add_link_graph_page');

function internal_link_scope_callback() {
    // security check
    if (!current_user_can('manage_options')) {
        return;
    }
    
    // Generate a nonce
    $nonce = wp_create_nonce('internal_link_scope');

    /* Add this back in later
        <div style="margin-bottom: 20px; font-size: 18px; line-height: 1.6;">
            A valuable tool for conducting in-depth SEO analysis, streamlining your content auditing process, or for gaining valuable insights into the structure and organization of your website's content.
        </div>

        <div style="margin-bottom: 60px;">
            <form method="post" action="<?php echo esc_url(admin_url('/admin-post.php')); ?>">
                <input type="hidden" name="action" value="export_headers">
                <input type="hidden" name="_wpnonce" value="<?php echo $nonce; ?>">
                <button type="submit" class="page-title-action" style="display: inline-block; text-decoration: none; background-color: #0071a1; color: #fff; padding: 10px 15px; border-radius: 3px;">Export Headers to CSV</button>
            </form>
        </div>
    */
?>
    <div class="wrap" style="font-family: Arial, sans-serif; padding: 20px; color: #333;">

        <h1 style="margin-bottom: 30px; font-size: 32px; color: #444;"><?php echo esc_html(get_admin_page_title()); ?></h1>
        
        <div style="margin-bottom: 20px; font-size: 18px; line-height: 1.6;">
            This is particularly useful for auditing your site's internal linking strategy, ensuring your content is well-interconnected and user navigation is optimized.
        </div>
        
        <div style="margin-bottom: 30px;">
            <button type="button" class="page-title-action" id="analyze_links_button" style="display: inline-block; text-decoration: none; background-color: #0071a1; color: #fff; padding: 10px 15px; border-radius: 3px;">Analyze Internal Links</button>
        </div>

        <div id="progress" style="margin-bottom: 30px; font-size: 18px; line-height: 1.6; display: none;">
            <progress id="progressBar" value="0" max="100"></progress> <span id="progressText">0%</span>
        </div>

        <div style="margin-bottom: 20px; font-size: 18px; line-height: 1.6;">
            Frase helps you write content that ranks better using keyword analysis on your competitors. (This is totally an affiliate link, but I use this product myself and recommend it)
        </div>

        <div style="margin-top: 30px; padding: 15px; background-color: #0071a1; color: #fff; text-align: center; border-radius: 3px;">
            <a href="https://www.frase.io/?via=mark71" style="font-size: 20px; font-weight: bold; text-decoration: none; color: #fff;">Boost your SEO Rankings with Frase!</a>
        </div>

    </div>

    <script>
        document.addEventListener('DOMContentLoaded', function() {
            var analyzeLinksButton = document.getElementById('analyze_links_button');
            analyzeLinksButton.addEventListener('click', function(e) {
                e.preventDefault();
                var progress = document.getElementById('progress');
                progress.style.display = 'block'; // Show the progress indicator when the button is pressed
                checkProgress();
            });
        });

        function checkProgress() {
            var url = '<?php echo admin_url('admin-ajax.php'); ?>';
            var data = new URLSearchParams();
            data.append('action', 'analyze_internal_links');
            data.append('_wpnonce', '<?php echo $nonce; ?>');

            fetch(url, {
                method: 'POST',
                body: data
            })
            .then(response => response.json())
            .then(jsonResponse => {
                // If progress is less than 100, call the function again
                if (jsonResponse.progress < 100) {
                    setTimeout(checkProgress, 200);
                }
                // Display the progress to the user
                var progressBar = document.getElementById('progressBar');
                var progressText = document.getElementById('progressText');
                progressBar.value = jsonResponse.progress;
                progressText.textContent = jsonResponse.progress.toFixed(2) + '%';
            })
            .catch(error => console.error('Error:', error));
        }
    </script>
<?php
}

function export_links_callback() {
    analyze_internal_links();

    wp_die();
}
add_action('wp_ajax_analyze_internal_links', 'export_links_callback');
